package com.example.Mutants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
