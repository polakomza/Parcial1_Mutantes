package service;

import dto.AdnSequenceRequest;
import model.AdnEntity;
import model.AdnSequence;
import repository.AdnRepository;
import util.AdnChecker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class AdnService {

    @Autowired
    private AdnRepository adnRepository;

    public boolean isMutant(AdnSequenceRequest adnSequenceRequest) {
        AdnSequence adnSequence = new AdnSequence();
        adnSequence.setDna(Arrays.asList(adnSequenceRequest.getDna()));
        char[][] dna = adnSequence.toCharMatrix();
        boolean isMutant = AdnChecker.isMutant(dna);

        AdnEntity adnEntity = new AdnEntity();
        adnEntity.setDna(adnSequence.getDna());
        adnEntity.setMutant(isMutant);
        adnRepository.save(adnEntity);

        return isMutant;
    }
}





