package com.example.Mutants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdnApplication {
	public static void main(String[] args) {
		SpringApplication.run(AdnApplication.class, args);
	}
}

