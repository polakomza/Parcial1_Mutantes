package dto;

import lombok.Data;

@Data
public class AdnSequenceRequest {
    private String[] dna;
}
