package dto;

import lombok.Data;

@Data
public class AdnSequenceResponse {
    private String message;
}
