package util;

public class AdnChecker {
    public static boolean isMutant(char[][] dna) {
        int n = dna.length;
        int m = dna[0].length;
        int mutantCount = 0;

        // Verificar filas
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= m - 4; j++) {
                if (checkSequence(dna, i, j, 0, 1)) {
                    mutantCount++;
                }
            }
        }

        // Verificar columnas
        for (int j = 0; j < m; j++) {
            for (int i = 0; i <= n - 4; i++) {
                if (checkSequence(dna, i, j, 1, 0)) {
                    mutantCount++;
                }
            }
        }

        // Verificar diagonales principales
        for (int i = 0; i <= n - 4; i++) {
            for (int j = 0; j <= m - 4; j++) {
                if (checkSequence(dna, i, j, 1, 1)) {
                    mutantCount++;
                }
            }
        }

        // Verificar diagonales secundarias
        for (int i = 0; i <= n - 4; i++) {
            for (int j = 3; j < m; j++) {
                if (checkSequence(dna, i, j, 1, -1)) {
                    mutantCount++;
                }
            }
        }

        return mutantCount >= 2;
    }

    private static boolean checkSequence(char[][] dna, int startRow, int startCol, int rowInc, int colInc) {
        char base = dna[startRow][startCol];
        for (int k = 1; k < 4; k++) {
            int i = startRow + k * rowInc;
            int j = startCol + k * colInc;
            if (dna[i][j] != base) {
                return false;
            }
        }
        return true;
    }
}


