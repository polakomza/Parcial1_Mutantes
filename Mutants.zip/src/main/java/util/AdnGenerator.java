package util;

import java.util.Random;

public class AdnGenerator {
    private static final char[] DNA_CHARACTERS = {'A', 'T', 'C', 'G'};
    private static final Random RANDOM = new Random();

    public static char[][] generateRandomDnaMatrix(int size) {
        char[][] dna = new char[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                dna[i][j] = DNA_CHARACTERS[RANDOM.nextInt(DNA_CHARACTERS.length)];
            }
        }
        return dna;
    }
}
