package model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class AdnEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ElementCollection
    @CollectionTable(name = "adn_dna", joinColumns = @jakarta.persistence.JoinColumn(name = "adn_id"))
    @Column(name = "dna")
    private List<String> dna;

    private boolean isMutant;
}


