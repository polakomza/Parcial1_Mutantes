package model;

import lombok.Data;

import java.util.List;

@Data
public class AdnSequence {
    private List<String> dna;

    public char[][] toCharMatrix() {
        char[][] charMatrix = new char[dna.size()][];
        for (int i = 0; i < dna.size(); i++) {
            charMatrix[i] = dna.get(i).toCharArray();
        }
        return charMatrix;
    }
}

