package controller;

import dto.AdnSequenceRequest;
import dto.AdnSequenceResponse;
import service.AdnService;
import util.AdnGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/adn")
public class AdnController {

    @Autowired
    private AdnService adnService;

    @PostMapping("/mutant")
    public ResponseEntity<AdnSequenceResponse> isMutant(@RequestBody AdnSequenceRequest adnSequenceRequest) {
        boolean isMutant = adnService.isMutant(adnSequenceRequest);
        AdnSequenceResponse response = new AdnSequenceResponse();
        response.setMessage(isMutant ? "Es mutante" : "No es mutante");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/generate")
    public ResponseEntity<AdnSequenceRequest> generateRandomDna() {
        char[][] dna = AdnGenerator.generateRandomDnaMatrix(6);
        AdnSequenceRequest adnSequenceRequest = new AdnSequenceRequest();
        adnSequenceRequest.setDna(new String[6]);
        for (int i = 0; i < 6; i++) {
            adnSequenceRequest.getDna()[i] = new String(dna[i]);
        }
        return ResponseEntity.ok(adnSequenceRequest);
    }
}



